﻿//// See https://aka.ms/new-console-template for more information
////using Lesson1.DayOne;
////using Lesson1.DayTwo;
////using Lesson1.DayThree;
////using Lesson1.Day5;
////using Lesson1.Day6;
////using Lesson1
//using Lesson1.Day7;
using Lesson1.Day10;
using Lesson1.Day8;
using Lesson1.DayFour;
//using Lesson1.DayTwo;

//DemoB.WriteBytesToMemoryStream();
//DemoB.ReadBytesFromMemor

Swapping.QuestionFour();








