﻿//Question 1
//Value types
/*Value types are similar to primitive types in java*/
//Value types are int,long,byte,short,float,double,char,boolean.

using System;
using System.Data;

namespace Question
{
    class One
    {


        public void Valuetypes()
        {
            int p = 8;
            int g = 5544;
            float f = 987.76f;
            long l = 9999999l;
            short s = 87;
            double d = 67d;
            decimal j = 8.43m;
            bool b = false;
            char a = 'v';
            Console.WriteLine(int.MaxValue);
            Console.WriteLine(f);
            Console.WriteLine(l);
            Console.WriteLine(s);
            Console.WriteLine(d);
            Console.WriteLine(j);
            Console.WriteLine(b);
            Console.WriteLine(a);
        }
    }
}

//Question 3






